//const numbers1 = {
var ALL_NUMBERS = {
  'ноль':         0,
  'один':         1,
  'два':          2,
  'три':          3,
  'четыре':       4,
  'пять':         5,
  'шесть':        6,
  'семь':         7,
  'восемь':       8,
  'девять':       9,
  'десять':       10,
  'одиннадцать':  11,
  'двенадцать':   12,
  'тринадцать':   13,
  'четырнадцать': 14,
  'пятнадцать':   15,
  'шестнадцать':  16,
  'семнадцать':   17,
  'восемнадцать': 18,
  'девятнадцать': 19,
//}
//const numbers2 = {
  'двадцать': 20,
  'тридцать': 30,
  'сорок': 40,
  'пятьдесят': 50,
  'шестьдесят': 60,
  'семьдесят': 70,
  'восемьдесят': 80,
  'девяносто': 90,
}
var STOP_WORD = 'ровно';
//const ALL_NUMBERS = assign({}, numbers1, numbers2);
//const STOP_NUMBERS = Object.assign({}, numbers1);
//const STOP_NUMBERS = Object.assign({}, numbers1, { [STOP_WORD]: null } );

//class Candidates {
  //constructor() {
  //  this.candidates = [
  //    [],
  //  ];
  //}
  //
  ///**
  // * создание новых кандидатов, добавляя слова/числа, соответсвующие каждому из вариантов
  // *
  // * @param  branchingParts string|number[][] массив, содержащий в себе варианты
  // *         - вложенные массивы с словами (или цифрами)
  // *         пример:  [ [ 22 ], [ 20, 2 ] ]
  // *
  // * Если на момент вызова имеется только 1 кандидат:
  // *   this.candidates:
  // *   [
  // *     [ 'бпм' ]
  // *   ]
  // * То с примеров параметров выше кандидаты будут изменены на следующие:
  // *   this.candidates: [
  // *     [ 'мпг', 22 ],
  // *     [ 'мпг', 20, 2 ]
  // *   ]
  // *
  // *
  // */
  //branch(branchingParts) {
  //  let newCandidates = [];
  //  //console.log('branch: enter: this.candidates:', this.candidates);
  //  //console.log('branch: enter: branchingParts:', branchingParts);
  //  branchingParts.forEach(parts => {
  //    const oldCandidates = this.candidates.slice();
  //    //console.log('branch: parts:', parts)
  //    //console.log('branch: oldCandidates: ', oldCandidates)
  //    const branchCandidates = oldCandidates.map(c => c = c.concat(parts));
  //    //console.log('branch: branchCandidates:', branchCandidates)
  //    newCandidates = newCandidates.concat(branchCandidates);
  //    //console.log('branch:', oldCandidates, parts, newCandidates)
  //  });
  //  this.candidates = newCandidates;
  //  //console.log('branch: exit: this.candidates', this.candidates)
  //}
  //
  ///**
  // * добавляет одну часть (строку/число) к каждому из кандидатов
  // *
  // * @param candidates
  // * @param part
  // */
  //addPart(part) {
  //  this.candidates.forEach(c => c.push(part));
  //}
  ///**
  // * добавляет массив "частей" (строк/чисел) к каждому из кандидатов
  // *
  // * @param candidates
  // * @param parts
  // */
  //addParts(parts) {
  //  this.candidates.forEach(c => c.concat(parts));
  //}
  //asStrings() {
  //  return this.candidates.map(c => c.join('-'));
  //}
//}


/**
 * создание новых кандидатов, добавляя слова/числа, соответсвующие каждому из вариантов
 *
 * Если на момент вызова имеется только 1 кандидат:
 *   this.candidates:
 *   [
 *     [ 'бпм' ]
 *   ]
 * То с примеров параметров выше кандидаты будут изменены на следующие:
 *   this.candidates: [
 *     [ 'мпг', 22 ],
 *     [ 'мпг', 20, 2 ]
 *   ]
 *
 * @param candidates string|number[][]
 * @param branchingParts string|number[] - массив, содержащий в себе варианты
 *         - вложенные массивы с словами (или цифрами)
 *         пример:  [ [ 22 ], [ 20, 2 ] ]
 * @returns string|number[][]
 */
function candidatesBranch(candidates, branchingParts) {
  var newCandidates = [];
  //console.log('branch: enter: this.candidates:', this.candidates);
  //console.log('branch: enter: branchingParts:', branchingParts);
  branchingParts.forEach(function(parts) {
    var oldCandidates = candidates.slice();
    //console.log('branch: parts:', parts)
    //console.log('branch: oldCandidates: ', oldCandidates)
    var branchCandidates = oldCandidates.map(function(c) { return c.concat(parts); });
    //console.log('branch: branchCandidates:', branchCandidates)
    newCandidates = newCandidates.concat(branchCandidates);
    //console.log('branch:', oldCandidates, parts, newCandidates)
  });
  candidates = newCandidates;
  //console.log('branch: exit: this.candidates', this.candidates)
  return candidates;
}

/**
 * добавляет одну часть (строку/число) к каждому из кандидатов
 *
 * @param candidates string|number[][]
 * @param part string|number
 * @returns string|number[][]
 */
function candidatesAddPart(candidates, part) {
  candidates.forEach(function(c) { return c.push(part) });
  return candidates;
}

/**
 *
 * @param candidates string|number[][]
 * @param parts string|number[]
 * @returns string|number[][]
 */
function candidatesAddParts(candidates, parts) {
  candidates.forEach(function(c) { return c.concat(parts); });
  return candidates;
}

/**
 *
 * @param candidates string|number[][]
 * @returns string[]
 */
function candidatesToStrings(candidates) {
  return candidates.map(function(c) { return c.join('-'); });
}


function process(s) {
  var candidates = [
    [],
  ];

  // разбить по пробелам
  var words = s.slice(7).split(/\s/);

  // для каждого слова
  var wordIndex = 0;
  while (wordIndex < words.length) {
    var currentWord = words[wordIndex];
    var nextWord = words[wordIndex+1]; // если вышли за границу массива, вернет undefined

    // смотрим слово в словаре
    var num = ALL_NUMBERS[currentWord];

    if (typeof num === 'undefined') {
      // если не нашли, сохраняем исходное слово
      candidatesAddPart(candidates, currentWord);

    } else if (
      num <= 19 || // числа, за которыми не может быть продолжения
      typeof nextWord === 'undefined' // последнее число в строке
    ) {
      // сохраняем соответствующее число
      candidatesAddPart(candidates, num);

    } else if (
      nextWord === STOP_WORD // слово "ровно" после десятков
    ) {
      // сохраняем соответствующее число
      candidatesAddPart(candidates, num);
      // пропускаем это слово
      wordIndex++;

    } else { // числа, за которыми может быть продолжение
      var nextNum = ALL_NUMBERS[nextWord];

      if (typeof nextNum === 'undefined') { // дальше чисел нет, сохраняем
        candidatesAddPart(candidates, num);

      } else {
        var fullNum = num + nextNum;
        //_candidates.branch(candidates, [
        candidates = candidatesBranch(candidates, [
          [ fullNum ],
          [ num, nextNum ],
        ]);

        // пропускаем следующее слово, так как уже обработали
        wordIndex++;

      }

    }
    // переходим к следующему слову
    wordIndex++;

  }

  return candidatesToStrings(candidates);
}