function showSchedule(note, context) {
    addAction({
        type: "show_schedule",
        note: note
    }, context);
}

function showTodaySchedule(note, context) {
    addAction({
        type: "for_today",
        note: note
    }, context);
}

function showTomorrowSchedule(note, context) {
    addAction({
        type: "for_tomorrow",
        note: note
    }, context);
}

function showThisWeekSchedule(note, context) {
    addAction({
        type: "for_this_week",
        note: note
    }, context);
}

function showNextWeekSchedule(note, context) {
    addAction({
        type: "for_next_week",
        note: note
    }, context);
}


function whenLesson(note, context) {
    addAction({
        type: "when_lesson",
        note: note
    }, context);
}

function whatLesson(note, context) {
    addAction({
        type: "what_lesson",
        note: note
    }, context);
}

function howManyLessons(note, context) {
    addAction({
        type: "how_many",
        note: note
    }, context);
}

function howManyLessonsLeft(note, context) {
    addAction({
        type: "how_many_left",
        note: note
    }, context);
}

function group(note, context) {
    addAction({
        type: "group",
        note: note
    }, context);
}

function subgroup(note, context) {
    addAction({
        type: "subgroup",
        note: note
    }, context);
}


// function parseToGroupFormat(line) {
//     var dict = {'один':1, 'два':2, 'три':3, 'четыре':4, 'пять':5, 'шесть':6, 'семь':7, 'восемь':8, 'девять':9, 'десять':10, 'одиннадцать':11, 'двенадцать':12, 'тринадцать':13, 'четырнадцать':14, 'пятнадцать':15, 'шестнадцать':16, 'семнадцать':17, 'восемнадцать':18, 'девятнадцать':19, 'двадцать':20, 'двадцать один':21, 'двадцать два':22 }
//     var words = line.split(" ");
//     line = line.slice(7)
//     for (var i = 0; i < words.length; i++) {
//         if (words[i] in dict) {
//             line = line.replace(words[i], dict[words[i]])
//             line = line.replace(" ", "-")
//         }
//     }
//     return line
// }


function willOrNowLesson(note, context) {
    addAction({
        type: "where",
        note: note
    }, context);
}

function goToProfile(note, context) {
    addAction({
        type: "profile",
        note: note
    }, context);
}

function firstLesson(note, context) {
    addAction({
        type: "first_lesson", 
        note: note
    }, context);
}

function daySchedule(note, context) {
    addAction({
        type: "day_schedule", 
        note: note
    }, context);
}
